BANDHAN CREATION Catalogue App — starter prototype

Included:
- Mobile-friendly catalogue manager
- Add catalogue names, category, description
- Upload multiple PDF/JPEG/PNG files
- Search and filter
- Preview and download files
- WhatsApp share text shortcut
- Data stored in this browser on this device using IndexedDB

Important limitations:
- This is a browser prototype, not a signed Android APK.
- Files/catalogues are not automatically available to customers or synced across devices.
- To publish for customers, the next step is hosting plus cloud storage/database and an admin login.
- WhatsApp sharing currently shares catalogue details text, not the attached PDF/image files themselves.
- Test with copies of files before relying on it for business records.

How to try:
1. Extract the ZIP.
2. Open index.html in Chrome. For best browser storage behavior, host it on HTTPS or run via a local web server.
3. Add a catalogue and choose PDF/JPEG files.
